<!DOCTYPE html>
<html>
<head>
    <title>Таблица умножения</title>
    <meta charset="UTF-8">
    <style>
        .mud-container {
            background: #2c3e50;
            color: #ecf0f1;
            padding: 20px;
            border: 2px solid #34495e;
            margin: 20px auto;
            max-width: 800px;
        }

        .mud-table {
            width: 100%;
            border-collapse: collapse;
            border: 1px solid #34495e;
            background: #34495e;
        }

        .mud-table th,
        .mud-table td {
            padding: 12px;
            border: 1px solid #34495e;
            text-align: center;
        }

        .mud-table th {
            background: #2c3e50;
            color: #ecf0f1;
        }

        .mud-table td {
            background: #ecf0f1;
            color: #2c3e50;
        }
    </style>
</head>
<body>
    <div class="mud-container">
        <?php
        echo "<table class='mud-table'>";
        echo "<tr><th>&times;</th>";

        // Заголовок таблицы
        for ($i = 0; $i <= 10; $i++) {
            echo "<th>$i</th>";
        }
        echo "</tr>";

        // Заполнение таблицы
        for ($i = 0; $i <= 10; $i++) {
            echo "<tr>";
            echo "<th>$i</th>";
            for ($j = 0; $j <= 10; $j++) {
                echo "<td>" . ($i * $j) . "</td>";
            }
            echo "</tr>";
        }
        echo "</table>";
        ?>
    </div>
</body>
</html>  