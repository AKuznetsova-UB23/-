<?php
session_start();

$host = 'localhost';
$dbname = 'zoo_db';
$username = 'root';
$password = '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
    die("Ошибка подключения к базе данных: " . $e->getMessage());
}

// Функция проверки аутентификации
function isAuthenticated() {
    return isset($_SESSION['user_id']);
}

// Функция проверки прав администратора
function isAdmin() {
    return isset($_SESSION['user_role']) && $_SESSION['user_role'] == 1;
}

// Функция для безопасного редиректа
function redirect($url) {
    header("Location: $url");
    exit;
}

// Функция для проверки доступа
function requireAuth() {
    if (!isAuthenticated()) {
        redirect('login.php');
    }
}

// Функция для проверки прав администратора
function requireAdmin() {
    requireAuth();
    if (!isAdmin()) {
        redirect('profile.php');
    }
} 