<?php $basePath = $basePath ?? ''; ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title><?php echo $pageTitle ?? 'Зоопарк'; ?></title>
    <link rel="stylesheet" href="<?php echo $basePath; ?>styles/common.css">
    <?php if (isset($currentStyle)): ?>
        <link rel="stylesheet" href="<?php echo $basePath; ?>styles/<?php echo $currentStyle; ?>.css">
    <?php endif; ?>
</head>
<body>
    <header class="main-header">
        <div class="container">
            <nav class="main-nav">
                <a href="<?php echo $basePath; ?>index.php" class="logo">Зоопарк</a>
                <div class="nav-links">
                    <a href="<?php echo $basePath; ?>index.php">Главная</a>
                    <?php if (isAuthenticated()): ?>
                        <?php if (isAdmin()): ?>
                            <a href="<?php echo $basePath; ?>admin/animals.php">Управление животными</a>
                            <a href="<?php echo $basePath; ?>users.php">Пользователи</a>
                        <?php endif; ?>
                        <a href="<?php echo $basePath; ?>my_donations.php">Мои пожертвования</a>
                        <a href="<?php echo $basePath; ?>profile.php">Профиль</a>
                        <a href="<?php echo $basePath; ?>logout.php">Выйти</a>
                    <?php else: ?>
                        <a href="<?php echo $basePath; ?>login.php">Войти</a>
                        <a href="<?php echo $basePath; ?>register.php">Регистрация</a>
                    <?php endif; ?>
                </div>
            </nav>
        </div>
    </header>
</body>
</html> 