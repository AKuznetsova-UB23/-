    <footer class="main-footer">
        <div class="container">
            <div class="footer-content">
                <div class="footer-section">
                    <h3>О нас</h3>
                    <p>Мы заботимся о животных и создаем для них лучшие условия</p>
                </div>
                <div class="footer-section">
                    <h3>Контакты</h3>
                    <p>Email: info@zoo.ru</p>
                    <p>Телефон: +7 (999) 123-45-67</p>
                </div>
                <div class="footer-section">
                    <h3>Адрес</h3>
                    <p>г. Москва, ул. Зоопарковая, 1</p>
                </div>
            </div>
            <div class="footer-bottom">
                <p>&copy; 2024 Зоопарк. Все права защищены.</p>
            </div>
        </div>
    </footer>
</body>
</html> 