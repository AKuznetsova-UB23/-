<?php
require_once 'config.php';

if (isAuthenticated()) {
    redirect('index.php');
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $login = $_POST['login'];
    $password = $_POST['password'];
    
    $stmt = $pdo->prepare("SELECT * FROM users WHERE login = ?");
    $stmt->execute([$login]);
    $user = $stmt->fetch();

    if ($user && password_verify($password, $user['password'])) {
        $_SESSION['user_id'] = $user['user_id'];
        $_SESSION['user_role'] = $user['role_id'];
        $_SESSION['user_name'] = $user['full_name'];
        
        redirect('index.php');
    }
    
    $error = "Неверный логин или пароль";
}

$pageTitle = "Вход | Зоопарк";
$currentStyle = "login";
require_once 'includes/header.php';
?>

<div class="container">
    <div class="login-container">
        <h2>Вход в систему</h2>
        <?php if (isset($error)): ?>
            <div class="error"><?php echo $error; ?></div>
        <?php endif; ?>
        <form class="login-form" method="post">
            <input type="text" name="login" placeholder="Логин" required>
            <input type="password" name="password" placeholder="Пароль" required>
            <button type="submit" class="login-button">Войти</button>
        </form>
        <div class="register-link">
            <p>Нет аккаунта? <a href="register.php">Зарегистрируйтесь</a></p>
        </div>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?> 