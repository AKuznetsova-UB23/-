<?php
require_once 'config.php';
requireAuth();

// Получаем ID животного из GET-параметра
$animal_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

// Получаем информацию о животном
$stmt = $pdo->prepare("SELECT * FROM animals WHERE animal_id = ?");
$stmt->execute([$animal_id]);
$animal = $stmt->fetch();

// Если животное не найдено, перенаправляем на главную
if (!$animal) {
    redirect('index.php');
}

// Обработка формы пожертвования
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $amount = floatval($_POST['amount']);
    $message = trim($_POST['message'] ?? '');
    
    if ($amount <= 0) {
        $error = "Сумма пожертвования должна быть больше нуля";
    } else {
        // Начинаем транзакцию
        $pdo->beginTransaction();
        
        try {
            // Добавляем пожертвование
            $stmt = $pdo->prepare("INSERT INTO donations (user_id, animal_id, amount, message) VALUES (?, ?, ?, ?)");
            $stmt->execute([$_SESSION['user_id'], $animal_id, $amount, $message]);
            
            // Обновляем текущую сумму пожертвований животного
            $stmt = $pdo->prepare("UPDATE animals SET current_amount = current_amount + ? WHERE animal_id = ?");
            $stmt->execute([$amount, $animal_id]);
            
            $pdo->commit();
            $success = "Спасибо за ваше пожертвование!";
            
        } catch (Exception $e) {
            $pdo->rollBack();
            $error = "Произошла ошибка при обработке пожертвования";
        }
    }
}

$pageTitle = "Пожертвование | " . $animal['name'];
$currentStyle = "donate";
require_once 'includes/header.php';
?>

<div class="container">
    <div class="donate-container">
        <div class="donate-header">
            <h2>Пожертвование для <?php echo htmlspecialchars($animal['name']); ?></h2>
        </div>

        <?php if (isset($success)): ?>
            <div class="success-message">
                <?php echo $success; ?>
                <div class="success-actions">
                    <a href="my_donations.php" class="button">Мои пожертвования</a>
                    <a href="index.php" class="button secondary">На главную</a>
                </div>
            </div>
        <?php else: ?>
            <?php if (isset($error)): ?>
                <div class="error-message"><?php echo $error; ?></div>
            <?php endif; ?>

            <div class="animal-info">
                <img src="<?php echo htmlspecialchars($animal['image_url']); ?>" 
                     alt="<?php echo htmlspecialchars($animal['name']); ?>"
                     class="animal-image">
                <div class="info-content">
                    <h3><?php echo htmlspecialchars($animal['name']); ?></h3>
                    <p class="species"><?php echo htmlspecialchars($animal['species']); ?></p>
                    <p class="description"><?php echo htmlspecialchars($animal['description']); ?></p>
                    <div class="donation-progress">
                        <div class="progress-bar">
                            <?php 
                            $percentage = ($animal['current_amount'] / $animal['target_amount']) * 100;
                            ?>
                            <div class="progress" style="width: <?php echo min(100, $percentage); ?>%"></div>
                        </div>
                        <div class="amounts">
                            <span>Собрано: <?php echo number_format($animal['current_amount'], 2); ?> ₽</span>
                            <span>Цель: <?php echo number_format($animal['target_amount'], 2); ?> ₽</span>
                        </div>
                    </div>
                </div>
            </div>

            <form method="post" class="donate-form">
                <div class="form-group">
                    <label>Сумма пожертвования (₽)</label>
                    <input type="number" name="amount" min="1" step="0.01" required>
                </div>

                <div class="form-group">
                    <label>Сообщение (необязательно)</label>
                    <textarea name="message" rows="3"></textarea>
                </div>

                <div class="form-actions">
                    <button type="submit" class="donate-button">Пожертвовать</button>
                    <a href="index.php" class="cancel-button">Отмена</a>
                </div>
            </form>
        <?php endif; ?>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?> 