<?php
require_once 'config.php';
requireAdmin();

// Удаление пользователя
if (isset($_POST['delete_user'])) {
    $user_id = $_POST['user_id'];
    $stmt = $pdo->prepare("DELETE FROM users WHERE user_id = ? AND role_id != 1");
    if ($stmt->execute([$user_id])) {
        $success = "Пользователь успешно удален";
    } else {
        $error = "Ошибка при удалении пользователя";
    }
}

// Получение списка пользователей
$stmt = $pdo->query("SELECT users.*, roles.role_name FROM users JOIN roles ON users.role_id = roles.role_id ORDER BY users.user_id");
$users = $stmt->fetchAll();

$pageTitle = "Управление пользователями | Зоопарк";
$currentStyle = "admin";
require_once 'includes/header.php';
?>

<div class="container">
    <div class="admin-container">
        <div class="admin-header">
            <h2>Управление пользователями</h2>
        </div>

        <?php if (isset($success)): ?>
            <div class="success-message"><?php echo $success; ?></div>
        <?php endif; ?>

        <?php if (isset($error)): ?>
            <div class="error-message"><?php echo $error; ?></div>
        <?php endif; ?>

        <table class="users-table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Логин</th>
                    <th>ФИО</th>
                    <th>Email</th>
                    <th>Телефон</th>
                    <th>Роль</th>
                    <th>Действия</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($users as $user): ?>
                <tr>
                    <td><?php echo $user['user_id']; ?></td>
                    <td><?php echo htmlspecialchars($user['login']); ?></td>
                    <td><?php echo htmlspecialchars($user['full_name']); ?></td>
                    <td><?php echo htmlspecialchars($user['email']); ?></td>
                    <td><?php echo htmlspecialchars($user['phone'] ?: '-'); ?></td>
                    <td><?php echo htmlspecialchars($user['role_name']); ?></td>
                    <td class="action-buttons">
                        <a href="edit_user.php?id=<?php echo $user['user_id']; ?>" 
                           class="edit-button">Редактировать</a>
                        <?php if ($user['role_id'] != 1): ?>
                        <form method="post" style="display: inline;">
                            <input type="hidden" name="user_id" value="<?php echo $user['user_id']; ?>">
                            <button type="submit" name="delete_user" class="delete-button" 
                                    onclick="return confirm('Вы уверены, что хотите удалить этого пользователя?')">
                                Удалить
                            </button>
                        </form>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>

        <div class="admin-actions">
            <a href="profile.php" class="back-button">Вернуться в профиль</a>
        </div>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?> 