<?php
require_once 'config.php';

// Получаем список животных
$stmt = $pdo->query("SELECT * FROM animals ORDER BY created_at DESC");
$animals = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Зоопарк | Помощь животным</title>
    <link rel="stylesheet" href="styles/common.css">
    <link rel="stylesheet" href="styles/index.css">
</head>
<body>
    <header class="main-header">
        <div class="container">
            <nav class="main-nav">
                <a href="index.php" class="logo">Зоопарк</a>
                <div class="nav-links">
                    <?php if (isAuthenticated()): ?>
                        <a href="profile.php">Профиль</a>
                        <a href="logout.php">Выйти</a>
                    <?php else: ?>
                        <a href="login.php">Войти</a>
                        <a href="register.php">Регистрация</a>
                    <?php endif; ?>
                </div>
            </nav>
        </div>
    </header>

    <main>
        <div class="container">
            <section class="hero">
                <h1>Помогите нашим животным</h1>
                <p>Выберите животное, которому хотите помочь</p>
            </section>

            <section class="animals-grid">
                <?php foreach ($animals as $animal): ?>
                    <div class="animal-card">
                        <img src="<?php echo htmlspecialchars($animal['image_url']); ?>" 
                             alt="<?php echo htmlspecialchars($animal['name']); ?>"
                             class="animal-image">
                        <div class="animal-info">
                            <h3><?php echo htmlspecialchars($animal['name']); ?></h3>
                            <p class="species"><?php echo htmlspecialchars($animal['species']); ?></p>
                            <p class="description"><?php echo htmlspecialchars($animal['description']); ?></p>
                            <div class="donation-progress">
                                <div class="progress-bar">
                                    <?php 
                                    $percentage = ($animal['current_amount'] / $animal['target_amount']) * 100;
                                    ?>
                                    <div class="progress" style="width: <?php echo min(100, $percentage); ?>%"></div>
                                </div>
                                <div class="amounts">
                                    <span>Собрано: <?php echo number_format($animal['current_amount'], 2); ?> ₽</span>
                                    <span>Цель: <?php echo number_format($animal['target_amount'], 2); ?> ₽</span>
                                </div>
                            </div>
                            <a href="donate.php?id=<?php echo $animal['animal_id']; ?>" 
                               class="donate-button">Помочь</a>
                        </div>
                    </div>
                <?php endforeach; ?>
            </section>
        </div>
    </main>

    <footer class="main-footer">
        <div class="container">
            <p>&copy; 2024 Зоопарк. Все права защищены.</p>
        </div>
    </footer>
</body>
</html> 