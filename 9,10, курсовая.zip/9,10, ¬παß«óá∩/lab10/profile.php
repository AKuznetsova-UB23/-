<?php
require_once 'config.php';
requireAuth();

$user_id = $_SESSION['user_id'];
$stmt = $pdo->prepare("SELECT * FROM users WHERE user_id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch();

$pageTitle = "Профиль | Зоопарк";
$currentStyle = "profile";
require_once 'includes/header.php';
?>

<div class="container">
    <div class="profile-container">
        <div class="profile-header">
            <h2>Профиль пользователя</h2>
        </div>
        
        <div class="profile-info">
            <div class="info-group">
                <div class="info-label">ФИО</div>
                <div class="info-value"><?php echo htmlspecialchars($user['full_name']); ?></div>
            </div>
            
            <div class="info-group">
                <div class="info-label">Email</div>
                <div class="info-value"><?php echo htmlspecialchars($user['email']); ?></div>
            </div>
            
            <div class="info-group">
                <div class="info-label">Телефон</div>
                <div class="info-value"><?php echo htmlspecialchars($user['phone'] ?: 'Не указан'); ?></div>
            </div>
        </div>
        
        <div class="profile-actions">
            <a href="edit_profile.php" class="profile-button edit-button">Редактировать профиль</a>
            <?php if (isAdmin()): ?>
                <a href="users.php" class="admin-link">Управление пользователями</a>
            <?php endif; ?>
            <a href="logout.php" class="profile-button logout-button">Выйти</a>
        </div>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?> 