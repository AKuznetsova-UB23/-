<?php
require_once '../config.php';
requireAdmin();

$upload_dir = '../uploads/animals/';
if (!file_exists($upload_dir)) {
    if (!mkdir($upload_dir, 0777, true)) {
        die('Не удалось создать папку для загрузки изображений');
    }
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = trim($_POST['name']);
    $species = trim($_POST['species']);
    $description = trim($_POST['description']);
    $target_amount = floatval($_POST['target_amount']);
    
    // Обработка загрузки изображения
    $image_url = '';
    if (isset($_FILES['image']) && $_FILES['image']['error'] == 0) {
        $allowed = ['jpg', 'jpeg', 'png', 'gif'];
        $filename = $_FILES['image']['name'];
        $ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
        
        if (in_array($ext, $allowed)) {
            $upload_dir = '../uploads/animals/';
            if (!file_exists($upload_dir)) {
                mkdir($upload_dir, 0777, true);
            }
            
            $new_filename = uniqid() . '.' . $ext;
            $upload_path = $upload_dir . $new_filename;
            
            if (move_uploaded_file($_FILES['image']['tmp_name'], $upload_path)) {
                $image_url = 'uploads/animals/' . $new_filename;
            } else {
                $error = "Ошибка при загрузке изображения";
            }
        } else {
            $error = "Недопустимый формат файла";
        }
    }
    
    if (!isset($error)) {
        $stmt = $pdo->prepare("INSERT INTO animals (name, species, description, image_url, target_amount) 
                              VALUES (?, ?, ?, ?, ?)");
        if ($stmt->execute([$name, $species, $description, $image_url, $target_amount])) {
            header("Location: animals.php");
            exit;
        } else {
            $error = "Ошибка при добавлении животного";
        }
    }
}

$pageTitle = "Добавление животного | Зоопарк";
$currentStyle = "admin_animals";
require_once '../includes/header.php';
?>

<div class="container">
    <div class="admin-container">
        <div class="admin-header">
            <h2>Добавление нового животного</h2>
        </div>

        <?php if (isset($error)): ?>
            <div class="error-message"><?php echo $error; ?></div>
        <?php endif; ?>

        <form method="post" enctype="multipart/form-data" class="animal-form">
            <div class="form-group">
                <label>Имя животного</label>
                <input type="text" name="name" required>
            </div>

            <div class="form-group">
                <label>Вид</label>
                <input type="text" name="species" required>
            </div>

            <div class="form-group">
                <label>Описание</label>
                <textarea name="description" rows="5" required></textarea>
            </div>

            <div class="form-group">
                <label>Фотография</label>
                <input type="file" name="image" accept="image/*" required>
            </div>

            <div class="form-group">
                <label>Необходимая сумма (₽)</label>
                <input type="number" name="target_amount" min="0" step="0.01" required>
            </div>

            <div class="form-actions">
                <button type="submit" class="save-button">Добавить</button>
                <a href="animals.php" class="cancel-button">Отмена</a>
            </div>
        </form>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?> 