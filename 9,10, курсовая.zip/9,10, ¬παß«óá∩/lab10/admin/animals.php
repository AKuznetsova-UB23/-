<?php
$basePath = '../';
require_once '../config.php';
requireAdmin();

// Обработка удаления животного
if (isset($_POST['delete_animal'])) {
    $animal_id = $_POST['animal_id'];
    
    // Получаем информацию о картинке
    $stmt = $pdo->prepare("SELECT image_url FROM animals WHERE animal_id = ?");
    $stmt->execute([$animal_id]);
    $animal = $stmt->fetch();
    
    // Удаляем файл картинки
    if ($animal && $animal['image_url']) {
        $file_path = '../' . $animal['image_url'];
        if (file_exists($file_path)) {
            unlink($file_path);
        }
    }
    
    // Удаляем запись из БД
    $stmt = $pdo->prepare("DELETE FROM animals WHERE animal_id = ?");
    if ($stmt->execute([$animal_id])) {
        $success = "Животное успешно удалено";
    } else {
        $error = "Ошибка при удалении животного";
    }
}

// Получение списка животных
$stmt = $pdo->query("SELECT * FROM animals ORDER BY created_at DESC");
$animals = $stmt->fetchAll();

$pageTitle = "Управление животными | Зоопарк";
$currentStyle = "admin_animals";
require_once '../includes/header.php';
?>

<div class="container">
    <div class="admin-container">
        <div class="admin-header">
            <h2>Управление животными</h2>
            <a href="add_animal.php" class="add-button">Добавить животное</a>
        </div>

        <?php if (isset($success)): ?>
            <div class="success-message"><?php echo $success; ?></div>
        <?php endif; ?>

        <?php if (isset($error)): ?>
            <div class="error-message"><?php echo $error; ?></div>
        <?php endif; ?>

        <div class="animals-list">
            <?php foreach ($animals as $animal): ?>
                <div class="animal-item">
                    <img src="../<?php echo htmlspecialchars($animal['image_url']); ?>" 
                         alt="<?php echo htmlspecialchars($animal['name']); ?>"
                         class="animal-thumbnail">
                    <div class="animal-details">
                        <h3><?php echo htmlspecialchars($animal['name']); ?></h3>
                        <p class="species"><?php echo htmlspecialchars($animal['species']); ?></p>
                        <div class="donation-info">
                            <span>Собрано: <?php echo number_format($animal['current_amount'], 2); ?> ₽</span>
                            <span>Цель: <?php echo number_format($animal['target_amount'], 2); ?> ₽</span>
                        </div>
                    </div>
                    <div class="animal-actions">
                        <a href="edit_animal.php?id=<?php echo $animal['animal_id']; ?>" 
                           class="edit-button">Редактировать</a>
                        <form method="post" class="delete-form">
                            <input type="hidden" name="animal_id" value="<?php echo $animal['animal_id']; ?>">
                            <button type="submit" name="delete_animal" class="delete-button"
                                    onclick="return confirm('Вы уверены, что хотите удалить это животное?')">
                                Удалить
                            </button>
                        </form>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?> 