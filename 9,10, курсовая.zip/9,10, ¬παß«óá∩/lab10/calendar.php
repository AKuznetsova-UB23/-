<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Календарь</title>
    <link rel="stylesheet" href="styles/common.css">
    <link rel="stylesheet" href="styles/calendar.css">
</head>
<body>
    <div class="container">
        <div class="calendar-container">
            <div class="calendar-grid">
                <!-- Дни календаря -->
                <div class="calendar-day">1</div>
                <div class="calendar-day">2</div>
                <!-- и т.д. -->
            </div>
        </div>
    </div>
</body>
</html> 