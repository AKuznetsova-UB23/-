<?php
require_once 'config.php';
requireAuth();

// Получаем пожертвования текущего пользователя
$stmt = $pdo->prepare("
    SELECT donations.*, animals.name as animal_name, animals.species 
    FROM donations 
    JOIN animals ON donations.animal_id = animals.animal_id 
    WHERE donations.user_id = ? 
    ORDER BY donations.created_at DESC
");
$stmt->execute([$_SESSION['user_id']]);
$donations = $stmt->fetchAll();

$pageTitle = "Мои пожертвования | Зоопарк";
$currentStyle = "donations";
require_once 'includes/header.php';
?>

<div class="container">
    <div class="donations-container">
        <div class="donations-header">
            <h2>Мои пожертвования</h2>
        </div>

        <?php if (empty($donations)): ?>
            <div class="no-donations">
                <p>У вас пока нет пожертвований.</p>
                <a href="index.php" class="button">Помочь животным</a>
            </div>
        <?php else: ?>
            <div class="donations-list">
                <?php foreach ($donations as $donation): ?>
                    <div class="donation-card">
                        <div class="donation-info">
                            <h3><?php echo htmlspecialchars($donation['animal_name']); ?></h3>
                            <p class="species"><?php echo htmlspecialchars($donation['species']); ?></p>
                            <p class="amount">Сумма: <?php echo number_format($donation['amount'], 2); ?> ₽</p>
                            <?php if ($donation['message']): ?>
                                <p class="message"><?php echo htmlspecialchars($donation['message']); ?></p>
                            <?php endif; ?>
                            <p class="date">Дата: <?php echo date('d.m.Y H:i', strtotime($donation['created_at'])); ?></p>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?> 