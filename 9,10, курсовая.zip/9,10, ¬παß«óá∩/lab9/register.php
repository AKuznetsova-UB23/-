<?php
require_once 'config.php';

if (isAuthenticated()) {
    redirect('profile.php');
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $login = trim($_POST['login']);
    $password = $_POST['password'];
    $full_name = trim($_POST['full_name']);
    $email = trim($_POST['email']);
    $phone = trim($_POST['phone']);
    
    // Проверка уникальности логина
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM users WHERE login = ?");
    $stmt->execute([$login]);
    if ($stmt->fetchColumn() > 0) {
        $error = "Этот логин уже занят";
    } else {
        // Создание нового пользователя
        $stmt = $pdo->prepare("INSERT INTO users (login, password, full_name, email, phone, role_id) VALUES (?, ?, ?, ?, ?, 2)");
        if ($stmt->execute([
            $login,
            password_hash($password, PASSWORD_DEFAULT),
            $full_name,
            $email,
            $phone
        ])) {
            redirect('login.php');
        } else {
            $error = "Ошибка при регистрации";
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Регистрация | Зоопарк</title>
    <link rel="stylesheet" href="styles/common.css">
    <link rel="stylesheet" href="styles/register.css">
</head>
<body>
    <div class="container">
        <div class="register-container">
            <h2>Регистрация</h2>
            <?php if (isset($error)): ?>
                <div class="error"><?php echo $error; ?></div>
            <?php endif; ?>
            <form class="register-form" method="post">
                <input type="text" name="login" placeholder="Логин" required>
                <input type="password" name="password" placeholder="Пароль" required>
                <input type="text" name="full_name" placeholder="ФИО" required>
                <input type="email" name="email" placeholder="Email" required>
                <input type="tel" name="phone" placeholder="Телефон">
                <button type="submit" class="register-button">Зарегистрироваться</button>
            </form>
            <div class="login-link">
                <p>Уже есть аккаунт? <a href="login.php">Войдите</a></p>
            </div>
        </div>
    </div>
</body>
</html>  