<?php
require_once 'config.php';
requireAuth();

$user_id = $_SESSION['user_id'];
$stmt = $pdo->prepare("SELECT * FROM users WHERE user_id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $full_name = trim($_POST['full_name']);
    $email = trim($_POST['email']);
    $phone = trim($_POST['phone']);
    
    if (!empty($_POST['new_password'])) {
        $password = password_hash($_POST['new_password'], PASSWORD_DEFAULT);
        $sql = "UPDATE users SET full_name = ?, email = ?, phone = ?, password = ? WHERE user_id = ?";
        $params = [$full_name, $email, $phone, $password, $user_id];
    } else {
        $sql = "UPDATE users SET full_name = ?, email = ?, phone = ? WHERE user_id = ?";
        $params = [$full_name, $email, $phone, $user_id];
    }
    
    $stmt = $pdo->prepare($sql);
    if ($stmt->execute($params)) {
        $success = "Данные успешно обновлены";
    } else {
        $error = "Ошибка при обновлении данных";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Редактирование профиля | Зоопарк</title>
    <link rel="stylesheet" href="styles/common.css">
    <link rel="stylesheet" href="styles/edit_profile.css">
</head>
<body>
    <div class="container">
        <div class="edit-container">
            <div class="edit-header">
                <h2>Редактирование профиля</h2>
            </div>
            
            <?php if (isset($success)): ?>
                <div class="success-message"><?php echo $success; ?></div>
            <?php endif; ?>
            
            <?php if (isset($error)): ?>
                <div class="error-message"><?php echo $error; ?></div>
            <?php endif; ?>
            
            <form class="edit-form" method="POST">
                <div class="form-group">
                    <label>ФИО</label>
                    <input type="text" name="full_name" value="<?php echo htmlspecialchars($user['full_name']); ?>" required>
                </div>
                
                <div class="form-group">
                    <label>Email</label>
                    <input type="email" name="email" value="<?php echo htmlspecialchars($user['email']); ?>" required>
                </div>
                
                <div class="form-group">
                    <label>Телефон</label>
                    <input type="tel" name="phone" value="<?php echo htmlspecialchars($user['phone']); ?>">
                </div>
                
                <div class="form-group">
                    <label>Новый пароль (оставьте пустым, если не хотите менять)</label>
                    <input type="password" name="new_password">
                </div>
                
                <div class="form-actions">
                    <button type="submit" class="save-button">Сохранить изменения</button>
                    <a href="profile.php" class="cancel-button">Отмена</a>
                </div>
            </form>
        </div>
    </div>
</body>
</html> 