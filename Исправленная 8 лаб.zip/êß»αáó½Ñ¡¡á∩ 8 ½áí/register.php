<?php
$message = '';
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Получаем данные из формы
    $fullname = trim($_POST['fullname'] ?? '');
    $login = trim($_POST['login'] ?? '');
    $password = $_POST['password'] ?? '';
    $birthdate = $_POST['birthdate'] ?? '';
    
    // Простая валидация
    $errors = [];
    
    if (empty($fullname)) {
        $errors[] = "ФИО обязательно для заполнения";
    }
    
    if (empty($login)) {
        $errors[] = "Логин обязателен для заполнения";
    }
    
    if (empty($password)) {
        $errors[] = "Пароль обязателен для заполнения";
    } elseif (strlen($password) < 6) {
        $errors[] = "Пароль должен быть не менее 6 символов";
    }
    
    if (empty($birthdate)) {
        $errors[] = "Дата рождения обязательна для заполнения";
    }
    
    if (empty($errors)) {
        // Здесь должен быть код для сохранения данных в базу
        $message = '<div style="color: green;">Регистрация успешно завершена!</div>';
    } else {
        $message = '<div style="color: red;">' . implode('<br>', $errors) . '</div>';
    }
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Регистрация</title>
    <style>
        .container {
            width: 400px;
            margin: 50px auto;
            padding: 20px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
        .form-group {
            margin-bottom: 15px;
        }
        label {
            display: block;
            margin-bottom: 5px;
        }
        input {
            width: 100%;
            padding: 8px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        button {
            background-color: #4CAF50;
            color: white;
            padding: 10px 15px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        button:hover {
            background-color: #45a049;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Регистрация пользователя</h2>
        
        <?php echo $message; ?>
        
        <form method="POST">
            <div class="form-group">
                <label for="fullname">ФИО:</label>
                <input type="text" id="fullname" name="fullname" value="<?php echo htmlspecialchars($_POST['fullname'] ?? ''); ?>">
            </div>
            
            <div class="form-group">
                <label for="login">Логин:</label>
                <input type="text" id="login" name="login" value="<?php echo htmlspecialchars($_POST['login'] ?? ''); ?>">
            </div>
            
            <div class="form-group">
                <label for="password">Пароль:</label>
                <input type="password" id="password" name="password">
            </div>
            
            <div class="form-group">
                <label for="birthdate">Дата рождения:</label>
                <input type="date" id="birthdate" name="birthdate" value="<?php echo htmlspecialchars($_POST['birthdate'] ?? ''); ?>">
            </div>
            
            <button type="submit">Зарегистрироваться</button>
        </form>
    </div>
</body>
</html>