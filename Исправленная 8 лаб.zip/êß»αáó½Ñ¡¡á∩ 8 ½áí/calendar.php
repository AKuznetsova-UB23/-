<?php
function getHolidays() {
    return [
        '1.1',  // Новый год
        '2.1',  // Новогодние каникулы
        '3.1',  // Новогодние каникулы
        '4.1',  // Новогодние каникулы
        '5.1',  // Новогодние каникулы
        '6.1',  // Новогодние каникулы
        '7.1',  // Рождество
        '23.2', // День защитника Отечества
        '8.3',  // Международный женский день
        '1.5',  // Праздник Весны и Труда
        '9.5',  // День Победы
        '12.6', // День России
        '4.11'  // День народного единства
    ];
}

function showCalendar($month = null, $year = null) {
    // Если параметры не заданы, используем текущую дату
    if ($month === null) $month = date('n');
    if ($year === null) $year = date('Y');
    
    $holidays = getHolidays();
    $firstDay = mktime(0, 0, 0, $month, 1, $year);
    $daysInMonth = date('t', $firstDay);
    $firstDayOfWeek = date('N', $firstDay);
    
    $monthNames = [
        1 => 'Январь', 'Февраль', 'Март', 'Апрель',
        'Май', 'Июнь', 'Июль', 'Август',
        'Сентябрь', 'Октябрь', 'Ноябрь', 'Декабрь'
    ];
    
    $calendar = "<h3>{$monthNames[$month]} $year</h3>";
    $calendar .= "<table border='1'>";
    $calendar .= "<tr>
                    <th>Пн</th>
                    <th>Вт</th>
                    <th>Ср</th>
                    <th>Чт</th>
                    <th>Пт</th>
                    <th style='color: red;'>Сб</th>
                    <th style='color: red;'>Вс</th>
                  </tr>";
    
    // Добавляем пустые ячейки в начале месяца
    $calendar .= "<tr>";
    for ($i = 1; $i < $firstDayOfWeek; $i++) {
        $calendar .= "<td></td>";
    }
    
    $dayOfWeek = $firstDayOfWeek;
    for ($day = 1; $day <= $daysInMonth; $day++) {
        $dateString = "$day.$month";
        $style = '';
        
        // Проверяем выходные и праздники
        if ($dayOfWeek >= 6 || in_array($dateString, $holidays)) {
            $style = 'background-color: #ffebeb; color: red;';
        }
        
        $calendar .= "<td style='$style'>$day</td>";
        
        if ($dayOfWeek == 7) {
            $calendar .= "</tr>";
            if ($day != $daysInMonth) {
                $calendar .= "<tr>";
            }
            $dayOfWeek = 1;
        } else {
            $dayOfWeek++;
        }
    }
    
    // Добавляем пустые ячейки в конце месяца
    while ($dayOfWeek <= 7 && $dayOfWeek != 1) {
        $calendar .= "<td></td>";
        $dayOfWeek++;
    }
    
    $calendar .= "</tr></table>";
    return $calendar;
}

// Обработка формы выбора месяца и года
$selectedMonth = isset($_POST['month']) ? (int)$_POST['month'] : date('n');
$selectedYear = isset($_POST['year']) ? (int)$_POST['year'] : date('Y');
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Календарь</title>
    <style>
        table {
            border-collapse: collapse;
            margin: 20px auto;
        }
        td, th {
            padding: 10px;
            text-align: center;
            width: 40px;
        }
        form {
            text-align: center;
            margin: 20px;
        }
    </style>
</head>
<body>
    <form method="post">
        <select name="month">
            <?php
            $months = [
                1 => 'Январь', 'Февраль', 'Март', 'Апрель',
                'Май', 'Июнь', 'Июль', 'Август',
                'Сентябрь', 'Октябрь', 'Ноябрь', 'Декабрь'
            ];
            foreach ($months as $num => $name) {
                $selected = ($num == $selectedMonth) ? 'selected' : '';
                echo "<option value='$num' $selected>$name</option>";
            }
            ?>
        </select>
        
        <select name="year">
            <?php
            $currentYear = date('Y');
            for ($year = $currentYear - 5; $year <= $currentYear + 5; $year++) {
                $selected = ($year == $selectedYear) ? 'selected' : '';
                echo "<option value='$year' $selected>$year</option>";
            }
            ?>
        </select>
        
        <input type="submit" value="Показать">
    </form>
    
    <?php echo showCalendar($selectedMonth, $selectedYear); ?>
</body>
</html>